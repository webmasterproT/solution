# Repository Structure

```
solution/
│
├── README.md                 # Start here. Overview. Links to everything.
├── MANIFESTO.md              # The full vision. Why this exists.
├── CONTRIBUTING.md           # How to help.
├── LICENSE                   # CC0 Public Domain. No rights reserved.
├── ROADMAP.md                # Phases and milestones.
├── JUSTIFICATIONS.md         # "What about..." — objections answered.
│
├── docs/
│   ├── TECHNICAL-SPEC.md     # Full architecture for builders.
│   └── STRUCTURE.md          # This file.
│
├── evidence/
│   ├── HEALTH.md             # Psychoneuroimmunology. Systems and disease.
│   ├── HEALTH-POLICY.md      # Food poison. Regulatory capture. Why voting matters.
│   ├── EMPATHY.md            # Research on empathy, plasticity, change.
│   └── ECONOMICS.md          # The $19T math. UBI. Bullshit jobs.
│
└── portfolios/
    ├── justice/
    │   ├── README.md         # Prison abolition. What replaces it.
    │   ├── dv.md             # Domestic violence specifically.
    │   └── serial-offending.md # The Bradley Edwards edge case.
    │
    ├── health/
    │   ├── README.md         # Overview.
    │   └── children.md       # Kids and poison food. Emergency.
    │
    ├── work/
    │   └── README.md         # Bullshit jobs. UBI. Time.
    │
    ├── housing/
    │   └── README.md         # The $250k per person math.
    │
    ├── education/
    │   └── README.md         # Learning by doing. Citizenship.
    │
    ├── treasury/
    │   └── README.md         # The $19T. How to redistribute.
    │
    └── substances/
        └── README.md         # Drug policy. Decrim. Harm reduction.
```

---

## Reading Order

**If you want the vision:**
1. README.md
2. MANIFESTO.md

**If you want to understand objections:**
1. JUSTIFICATIONS.md

**If you want to build:**
1. docs/TECHNICAL-SPEC.md
2. ROADMAP.md
3. CONTRIBUTING.md

**If you want the evidence:**
1. evidence/HEALTH.md
2. evidence/HEALTH-POLICY.md

**If you care about specific issues:**
1. portfolios/[topic]/README.md

---

## Why This Structure

**Root level:** The essentials. What you need to understand and contribute.

**docs/:** Technical documentation for builders.

**evidence/:** Research and sources. The "why" backed by data.

**portfolios/:** Specific policy areas. How the token system applies to each.

---

## Contributing to Structure

See something missing? Wrong place? Open an issue or PR.

This is a living repo. It will grow and change.

The structure serves the mission, not the other way around.
