# Serial Offending — The Edge Case

> "The priority is the harmed and potential future victims — dignity is included because it makes long-term safety more reliable. Anyone incarcerated will eventually be your neighbour. Including Bradley Edwards. This is a principle in Norway — a country with some of the lowest recidivism rates in the world."

---

## The Case People Use to Defend Prisons

Bradley Edwards. The Claremont Killer.

Convicted of murdering Jane Rimmer and Ciara Glennon. Acquitted of Sarah Spiers (who has never been found).

This is the edge case. Someone who hunted women for years. Predatory. Pattern. Not situational. Not desperation. Not a relationship gone wrong.

**And it's also the case that proves the current system doesn't keep anyone safe.**

---

## What Actually Happened

**1990 — Hollywood Hospital Attack:**
- Grabbed a woman at work
- Dragged her to a bathroom
- Held her
- Looked in her eyes
- Shook his head
- Let her go

Classic rehearsal behavior. A man who *chose to stop this time.*

**The System's Response:**
- Charged with common assault (minimised)
- Kept his job
- Victim not part of the process
- Released

**What He Learned:**
I can do this and the system will protect me.

**Then:**
- Karrakatta cemetery rape
- Jane Rimmer murdered
- Ciara Glennon murdered
- Sarah Spiers... missing forever

**The system designed to keep us safe had him. And released him.**

Zero victim involvement. Zero community visibility. Zero empathy process.

---

## The Question

For the 0.1% — predatory, pattern, won't stop — the question isn't "how much punishment."

**The question is: How do we keep everyone safe, especially potential future victims, while refusing to abandon basic human rights?**

---

## A Working Framework

### What Doesn't Work
A cage that makes him worse isn't safety. It's slow violence we don't have to look at.

### What Might Work

**Contained community, not cage:**
- Small community of people living together
- Supervised, visible
- Not a concrete box
- Dignity, work, therapy, human connection
- But doesn't leave unsupervised. Not ever.

**Still a token holder:**
- Still votes
- Still has empathy invitations within that space
- Still human

**Permanent proximity limits:**
- Cannot be unsupervised in general community
- Not as punishment — as reality
- The risk is too high

**Affected families have power:**
- The families of Jane, Ciara, Sarah shape the safety plan
- Not a judge. Them.
- Within human rights boundaries.

---

## Current vs Token System

### Current System
- Early predatory violence minimised
- Victim sidelined
- Released with no oversight
- Pattern not identified
- Women murdered

### Token System
- Victim central to process
- Empathy invitation — lives a version of her experience
- Proximity meeting — he faces her, she speaks, he listens
- Community sees the pattern
- Parent at workplace doesn't get to vouch — the person he harmed does (or doesn't)
- Ongoing proximity checks
- Pattern identified early
- Protective measures *before* escalation

---

## What Our System Guarantees

**We can't guarantee he changes.**

We can guarantee:
- He's seen
- She's heard
- The community knows
- The pattern gets caught
- The families are involved
- Nobody pretends the revenge-box keeps anyone safe

---

## The Argument

The argument against abolition is always Bradley Edwards.

But Bradley Edwards is actually the argument **for** abolition.

Because the prison system had him. And let him go. Without any of the things that might have actually mattered.

The current system failed those women. Not our hypothetical system. The actual one we have now.

---

## The Honest Answer

For the 0.1%: contained community, not cage.

Honest about the limits. Still human.

It doesn't pretend we can "fix" someone who hunts. It just chooses reliable safety without revenge architecture.

Maybe the answer for the 0.1% is: still in the system, just with permanent proximity limits.

Not perfect. But real. And it doesn't make everything worse the way the current system provably does.
