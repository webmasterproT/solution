# Domestic Violence

---

## Why DV Exists

- **Isolation.** Abuser cuts victim off from community.
- **Secrecy.** No one sees what happens inside.
- **Slow response.** Police take 20 mins. Damage done.
- **Victim not believed.** System is adversarial.
- **Abuser controls the story.**

---

## Token System Response

| Abuser Tactic | Current System | Token System |
|---------------|----------------|--------------|
| Isolate victim | Easy | Impossible — community sees |
| Control narrative | Works | Can't — transparency |
| Victim not believed | Common | Vouch network knows them |
| Slow response | 20+ mins | 60 seconds |
| Hide abuse | Secrecy default | Visibility default |

---

## How It Works

### Transparency
Community can see patterns. Person stops coming to meetings. Stops responding. Red flags visible.

### Safety Button
Instant. Local responders. 60 seconds not 20 minutes.

### Vouch Network
You're never truly alone. The 3 people who vouched for you — they see you.

### Can't Isolate
Isolation is the abuser's main tool. Mutual visibility breaks it.

### Community Response
Not cops who don't believe you. People who know you.

---

## The Research

Safety buttons work. Fast response works. Community connection works.

Current system has all three broken. Token system has all three fixed.

---

## The Outcome

This isn't an incremental improvement. It's structural elimination.

This could actually **end** DV. Not reduce it. End it.

Because the mechanisms that enable it — isolation, secrecy, slow response, disbelief — all break under mutual visibility and community response.

---

## For Survivors Hiding from Abusers

Community-granted privacy exceptions.

The community can make you invisible to specific people while remaining visible to your support network.

Abuser gets watched. Victim gets protected.

The transparency is a tool. It cuts both ways — and we aim it at the threat.
