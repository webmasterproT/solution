# Justice Portfolio

> Not "how do we make prisons better." How do we not have them.

---

## The Logic

Most "crime" disappears under the token system:
- **UBI eliminates survival crime** — no stealing to eat
- **Drugs decriminalized** — pharmacist-assisted, harm reduction
- **Poverty gone** — $19T distributed
- **Bullshit jobs gone** — time, stability, connection

Most of what fills prisons evaporates.

---

## What's Left Is Harm

Real harm, person to person. For that:

1. **Meeting is called.** Affected people attend. Proximity basis.
2. **Empathy invitation if needed.** Person who harmed lives in life of person harmed.
3. **People involved decide repair.** Not a judge. Not policy. Them.
4. **If still danger right now** — the hula hoop. Visible boundary. Consensual. Temporary.
5. **Process iterates** until resolved.

---

## By Crime Type

### Stealing / B&E
**Gone.** UBI. No survival crime.

### Gang Crime
**Mostly gone.** Belonging, identity, survival met other ways. What's left is interpersonal, handled by meetings.

### DV
See: [dv.md](dv.md)
- Immediate separation
- Empathy invitation (with survivor community, not victim directly)
- Proximity meeting when safe
- Permanent proximity limits if needed

### White Collar
- Full financial transparency
- Stole from 10,000 people? Meeting with 10,000 people
- Material repair — you give back
- Empathy swap with someone whose retirement you destroyed

### Rape
Hardest one.
- Harmed person may never want proximity
- Empathy swap with survivors willing to participate
- Visible marker in community?
- Exclusion from spaces?
- **Community decides, not judge**

### Murder
- Harmed person can't swap. Family can.
- Question: situational (one-time) or pattern?
- Most murders are situational
- Process runs. Repair as affected parties define.

### Serial Killer
See: [serial-offending.md](serial-offending.md)
- The 0.1% edge case
- Contained community, not cage
- Permanent proximity limits
- Still token holder. Still human.

---

## The Point

The question "what replaces prisons" might not have a single answer.

Different communities figure out different things through the process.

The point is: **people who live with the outcome decide.** Not distant legislators. Not professionals insulated from both sides.

---

## Current System Costs

- **$400/day per prisoner**
- **45% recidivism**
- **$32 billion/year** in Australia alone
- **We pay to make people worse**

5 star hotel with butler would be cheaper AND more effective.

---

## See Also

- [dv.md](dv.md) — Domestic violence specifically
- [serial-offending.md](serial-offending.md) — The Bradley Edwards case
