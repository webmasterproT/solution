# Health Portfolio

> "Between 30–50% of all cancer cases are preventable." — WHO

---

## The Core Problem

The system makes us sick. Not through malice — through design.

- Isolation increases inflammation
- Chronic stress damages immune function
- Lack of community accelerates disease
- Feeling powerless shortens lives
- Poison is cheaper than vegetables
- Kids eat carcinogens for breakfast

---

## The Numbers

- **70-90% of cancers** are caused by extrinsic factors we could change
- **Heart disease** is the #1 killer — largely preventable
- **$220+ billion/year** on healthcare
- **~2%** goes to prevention
- **$1.40 invested in prevention = $13 saved** in treatment

We know how to prevent disease. The system isn't designed to.

---

## The Token System Response

| Health Factor | Current System | Token System |
|---------------|----------------|--------------|
| Social connection | Declining, atomised | Built-in via vouch network |
| Stress response | Chronic, uncontrollable | Reduced via safety button, community |
| Sense of purpose | Work often meaningless | Direct participation in governance |
| Control | Minimal | Proximity-weighted voting |
| Time | Extracted by bullshit jobs | Freed by UBI |
| Food policy | Controlled by industry | Controlled by people who eat it |

---

## Evidence

See:
- [evidence/HEALTH.md](../../evidence/HEALTH.md) — Psychoneuroimmunology. How stress and connection change immune function.
- [evidence/HEALTH-POLICY.md](../../evidence/HEALTH-POLICY.md) — Food system poison. Regulatory capture. The Happy Meal test.

---

## Children at Risk

See: [children.md](children.md)

2.5 million Happy Meals per day. Ice cream with carcinogens. Bacon with the same cancer rating as cigarettes.

If you gave your child these substances, you'd be investigated.

If a corporation does it with a cartoon mascot, it's "breakfast."

---

## What Proximity Voting Would Change

If affected people voted directly:

1. **Warning labels on processed meat** — Same as cigarettes
2. **Subsidies redirected** — From corn/soy to vegetables
3. **Advertising restrictions** — No marketing junk to children
4. **Sugar tax** — Revenue to healthy food subsidies
5. **Investment shift** — From treatment to prevention
6. **True cost pricing** — Health externalities included

None of this is radical. Other countries do it. We just don't because the people harmed don't make the decisions.

---

## The Connection

This isn't separate from the token system. It's why the token system matters.

People who eat the food should decide what's in it.
People who pay health costs should decide health policy.

The token system doesn't guarantee perfect policy. It guarantees the people harmed by bad policy get to change it.
